# Verification

Date: 2026-09-13
Version: 0.5.1

## Current delivery scope

本轮交互优化直接基于用户提供的 `StarBox-0.5.1-release-fork-rebased.zip` 工作副本，在既有 Release/Fork 能力和 `stars-simplified` 继承合同之上进行最小增量修改：Stars 多选操作栏改为底部居中圆角浮动栏，修复登录页密码可见性按钮定位，Stars 与 Discover 的单仓库 Unstar 增加二次确认，并将 Stars 排序固定为最近星标 / 最近活跃 / 最多星标。全程仅修改 `/mnt/data` 工作副本，未写入 Git 仓库、未创建 PR、未推送远端。

当前产品边界：

- Stars 固定卡片视图；多选位于卡片右上角；多选操作使用底部居中的圆角浮动操作栏；仓库业务操作全部使用底部 icon actions；元信息按 Star 数量 → 语言 → 更新时间展示，不显示 Fork 数量或 License。
- Activity 页面、导航与 public `/api/activity` 已移除；`activity_log` 仅保留为服务端内部审计表。
- 全局 Command / 快速跳转已移除。
- Release/Fork **不再提供任何已读/未读功能**；当前前端状态不包含 `releaseStates` / `forkReadAt`，业务 mutation 不包含 `release.read` / `release.unread` / `fork.read`。
- Release 仍只消费 Stars subscription；新增 Timeline / Repository Group、Asset 平台/类型快捷筛选、AI Release Summary。
- Fork 仍只管理已有 GitHub Fork；新增 Actions 状态筛选、Workflow definitions 与 `workflow_dispatch` 手动触发。

## Final packaging-container result

最终源码执行：

```bash
npm run check
```

结果：**PASS**。

- Typecheck：PASS，当前容器明确为 fallback-shim mode。
- Automated tests：**98/98 PASS**。
- Build：PASS，当前容器明确为 fallback import-map mode。
- Fast UI structural verification：**7 routes PASS**。
- Raster verification：**7 routes PASS**。
- `workers_dev: false`：保持不变。

额外执行：

```bash
npm run check:installed
```

当前容器结果：**exit 2**。原因是未安装真实 React / React DOM / Remix Icon / Base UI package types。该 gate 明确拒绝 fallback，因此 **installed-package gate 不宣称通过**。

真实 Playwright package 在当前环境不可用，**real-browser E2E 不宣称通过**。真实 Cloudflare production smoke 未执行。

## Automated coverage — 98 tests

覆盖包括：

- StarBox 服务端登录、fallback credential warning、login rate limit。
- D1 opaque session、secure cookie、expiry/logout/revoke、same-origin mutation guard。
- Session `last_seen_at` write throttling。
- GitHub credential validate / AES-256-GCM encryption / replace / delete / second-device reuse。
- D1 authoritative bootstrap / changes / IndexedDB entity-cache contract。
- Stars single star/unstar + batch unstar、batch-star hard reject、GitHub full-sync external unstar reconciliation、bootstrap tombstone filtering。
- Stars 单一卡片视图、Repository Card selection/action/metadata contracts。
- `stars-simplified` 继承合同：URL state、Stars filtered selection/destructive confirmation、Repository Editor dirty guard、Repository Detail Tabs/retry、Lists local draft/unsaved guard、Discover remote-vs-local query split、Notifications rollback、Settings deep-link/import preview/Regex test、IndexedDB clear、Activity public handler removal。
- 本轮交互收口：Stars 多选底部圆角浮动栏；Login 密码可见性按钮保持输入框内居中；Stars/Discover 单仓库 Unstar 二次确认；Stars 排序固定为最近星标 / 最近活跃 / 最多星标，最近活跃使用 `pushed_at`。
- Repository metadata、Category create/update/delete/reorder/batch assignment。
- AI organize summary/tags/category authoritative persistence。
- Release normalization/detail/incremental sync、Stars-owned subscription mutations、Release-page no-subscribe contract、release sync state。
- Release read-state removal：UI/state/store/mutation 均无已读/未读产品能力。
- Release Timeline / Repository Group、Asset quick filters、AI Release Summary API/structured response contract。
- Fork creation endpoint hard-disabled (405 + zero GitHub create calls)、existing Fork inventory/divergence/Actions/upstream sync。
- Fork read-state removal：无 `forkReadAt` / `fork.read`。
- Fork Workflow definitions 与 `workflow_dispatch` proxy（ref + inputs）。
- GitHub Lists snapshot/CRUD/membership mirror 与 delete cleanup。
- Discover query construction。
- Notifications producer/read-state contracts。
- Activity product/public endpoint removal；internal audit producer 保留。
- COSS/Base UI core behavior-primitives contract。
- build fallback vs installed-bundle contract。
- credential-redacted export / browser-local AI secret contract。

## Release interaction contract

- Stars 是唯一 Release subscription 管理入口。
- Release 页面没有 Watching Import、Custom Sources 或直接 subscribe/unsubscribe。
- 没有 All/Unread/Read、Mark Read、Mark All Read 等入口。
- Timeline：按发布时间浏览当前筛选结果。
- Repository Group：按 `repoFullName` 聚合 Release。
- Asset quick filters：
  - platform：All / macOS / Windows / Linux / ARM
  - type：All / DMG / ZIP / AppImage / EXE-MSI / DEB-RPM / APK / TAR-7Z
  - Settings 中 include/exclude Regex 继续叠加。
- AI Release Summary 使用现有 Custom HTTP Provider，结构为 `overview / highlights / fixes / breakingChanges`。

## Fork interaction contract

- 只读取当前 GitHub Account 已存在的 Fork；平台内创建入口继续禁止。
- 没有 unread badge、read filter、mark-read mutation。
- 筛选：Upstream 状态 + Actions 状态 + text search。
- Actions 状态：Success / Failure / Running / None。
- Detail 加载 GitHub Workflow definitions。
- Workflow dispatch：选择 Workflow、Ref / Branch，可选 Inputs JSON；Worker 代理 GitHub `workflow_dispatch`。
- 目标 Workflow 不支持手动触发、Token 权限不足或 GitHub API 拒绝时，由现有错误反馈链展示失败。

## UI structural verification

`npm run ui:verify` 使用确定性 React-compatible SSR harness + production Tailwind CSS。当前验证 **7 routes**：

- `/` — Stars
- `/releases` — Release
- `/forks` — Fork
- `/lists` — GitHub Lists
- `/discover` — Discover
- `/notifications` — Notifications
- `/settings` — Settings

Harness 会 stub RemixIcon 与 Base UI runtime，因此证明 route structure、主要内容与 composition 可渲染，不证明真实浏览器 focus / portal / keyboard / positioning 行为。

`npm run ui:verify:raster` 当前 7 routes PASS。Raster 仍来自确定性 harness，不替代 Playwright E2E。

## COSS UI verification

当前产品实际使用的 primitive set：

```text
Button / Input / Textarea / Field
Badge / Alert / Card
Dialog / Select / Checkbox / Switch
Menu / Tooltip / Toast / Tabs
Pagination
Toolbar / ToggleGroup / Table / AlertDialog
Skeleton
```

全局 Command primitive 已从当前产品源码移除；Activity 页面也已移除。

## Installed-package handoff

联网机器执行：

```bash
npm install
npm run check:installed
```

生产就绪前要求：

- 使用真实 React / React DOM / Remix Icon / Base UI package types；
- 98+ tests PASS；
- build 报告 `bundled local dependencies`；
- 7-route structural verifier PASS；
- Playwright 验证 Login、Dialog、Select、Checkbox、Switch、Menu、Tooltip、Toast，以及 Release AI Summary / Fork workflow_dispatch 等关键 mutation。

## Cloudflare production handoff

部署前：

```bash
wrangler secret put LOGIN_PASSWORD
wrangler secret put GITHUB_TOKEN_ENCRYPTION_KEY
```

配置真实 D1 database ID、应用 migrations、绑定 custom domain/route 后，在 installed-package gate 通过的环境执行部署与 smoke。

Production smoke：Login → GitHub credential connect → Stars sync → Release（Timeline/Repository Group/Asset/AI Summary）→ Fork（filters/upstream sync/workflow_dispatch）→ Lists → Discover → Notifications → Settings，并验证第二设备复用加密 GitHub credential。
